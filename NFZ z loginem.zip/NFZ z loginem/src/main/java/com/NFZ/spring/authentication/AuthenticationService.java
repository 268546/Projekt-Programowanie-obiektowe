package com.NFZ.spring.authentication;

import com.NFZ.spring.config.JwtService;
import com.NFZ.spring.security.Role;
import com.NFZ.spring.security.User;
import com.NFZ.spring.security.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthenticationService {// tu implementujemy register i authenticate

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;
    public AuthenticationResponse register(RegisterRequest request) { // to stworzy uzytkownika i zwroci mu token
        var user = User.builder()
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(Role.USER)
                .build(); // tworzenie uzytkownika
        userRepository.save(user);
        var jwtToken = jwtService.generateTokenUserOnly(user); // tutaj generuje token
        return AuthenticationResponse.builder().token(jwtToken).build();
    }

    public AuthenticationResponse authenticate(AuthenticationRequest request) { // robi authenticate na podstawie emala i hasla
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        );
        var user = userRepository.findByEmail(request.getEmail()) // jesli przechodzisz poprzednie 3 linijki to oznacza ze user istnieje
                .orElseThrow();
        var jwtToken = jwtService.generateTokenUserOnly(user); // tutaj generuje token
        return AuthenticationResponse.builder().token(jwtToken).build();
    }

}
