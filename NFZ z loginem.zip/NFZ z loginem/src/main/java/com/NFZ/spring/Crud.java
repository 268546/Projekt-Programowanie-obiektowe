package com.NFZ.spring;

import org.springframework.data.repository.CrudRepository;

public interface Crud extends CrudRepository<Users,Integer> {
}
