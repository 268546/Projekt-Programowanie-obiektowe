package com.NFZ.spring;

import org.springframework.data.repository.CrudRepository;
import com.NFZ.spring.Doctors;

public interface CrudDoc extends CrudRepository<Doctors, Integer> {
}
