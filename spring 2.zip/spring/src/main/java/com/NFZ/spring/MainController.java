package com.NFZ.spring;


import jakarta.persistence.Id;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

import javax.print.Doc;
import java.math.BigInteger;

@Controller
public class MainController {

    @Autowired
    private Crud crud;
    @Autowired
    private CrudDoc crudDoc;

    @PostMapping(path = "/addDoctors")
    public String addNewDoctor (@RequestParam String Nazwa, @RequestParam String Specjalizacja){
        Doctors nDoctors = new Doctors();
        nDoctors.setNazwa(Nazwa);
        nDoctors.setSpecjalizacja(Specjalizacja);
        crudDoc.save(nDoctors);
        return "DodanieLekarzy";
    }

    @PostMapping(path="/addUsers")
    public String addNewUser (@RequestParam String Imie, @RequestParam String Nazwisko,
                                            @RequestParam BigInteger Pesel, @RequestParam String Miasto,
                                            @RequestParam String Ulica, @RequestParam Integer NumerDomu,
                                            @RequestParam String Email, @RequestParam String Specjalizacja,
                                            @RequestParam String Datawizyty, @RequestParam String Datauro) {


        //if (crud.existsById(2)) {
         //   return "Lekarze";
        //}else{
            Users nUsers = new Users();
            nUsers.setImie(Imie);
            nUsers.setNazwisko(Nazwisko);
            nUsers.setPesel(Pesel);
            nUsers.setMiasto(Miasto);
            nUsers.setUlica(Ulica);
            nUsers.setNumerDomu(NumerDomu);
            nUsers.setEmail(Email);
            nUsers.setDatawizyty(Datawizyty);
            nUsers.setDatauro(Datauro);
            nUsers.setSpecjalizacja(Specjalizacja);
            crud.save(nUsers);
            return "NFZstrona";
        //}
        /*
        int searchId = 23232; // ID of the Car
        boolean exists = crud.existsById(searchId);
        System.out.println(exists);
        return "NFZstrona";*/

    }

    @GetMapping(path="/all")
    public @ResponseBody Iterable<Users> getAllUsers() {
        return crud.findAll();
    }
    @GetMapping(path="/doctors")
    public @ResponseBody Iterable<Doctors> getAllDoctors() {
        return crudDoc.findAll();
    }

    @GetMapping(path = "/lekarze")
    public String lekarze(Model model){
        Iterable<Doctors> Doctorslist =crudDoc.findAll();
        model.addAttribute("Doctorslist", Doctorslist);
        return "Lekarze";
    }
    @GetMapping(path = "/Wizyty")
    public String wizyty(Model model){
        Iterable<Users> Userslist =crud.findAll();
        model.addAttribute("Userslist", Userslist);
        return "Wizyty";
    }






    @GetMapping(path = "/")
    public String powrot(){
        return "NFZstrona";
    }

    @GetMapping(path = "/dodanie")
    public String dodanie(){
        return "DodanieLekarzy";
    }

}

