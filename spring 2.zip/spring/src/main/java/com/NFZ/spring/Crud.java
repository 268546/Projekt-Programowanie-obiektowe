package com.NFZ.spring;

import org.springframework.data.repository.CrudRepository;
import com.NFZ.spring.Users;

public interface Crud extends CrudRepository<Users,Integer> {
}
