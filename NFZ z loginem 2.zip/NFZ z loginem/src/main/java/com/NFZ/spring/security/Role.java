package com.NFZ.spring.security;

public enum Role {
    USER,
    ADMIN
}
