package com.NFZ.spring.security;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Integer> {
    Optional<User>findByEmail(String email); //zeby wyszukac urzytkownika
    //https://www.javappa.com/kurs-java/java8/klasa-optional
}
